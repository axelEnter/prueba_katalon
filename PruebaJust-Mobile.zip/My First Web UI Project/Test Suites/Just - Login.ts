<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Validaciones generales de Login</description>
   <name>Just - Login</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>38ff01e2-c2c5-47a6-b472-19d8f09f218e</testSuiteGuid>
</TestSuiteEntity>
