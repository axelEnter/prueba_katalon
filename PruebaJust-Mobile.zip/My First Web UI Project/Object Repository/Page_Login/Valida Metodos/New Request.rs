<?xml version="1.0" encoding="UTF-8"?>
<WebServiceRequestEntity>
   <description>Metodo para obtener los token de seguridad para poder ingresar a la pagina del sitio.</description>
   <name>New Request</name>
   <tag></tag>
   <elementGuidId>00dbf18f-17ca-4b29-8102-18fdd4dfd8c2</elementGuidId>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <autoUpdateContent>true</autoUpdateContent>
   <connectionTimeout>0</connectionTimeout>
   <followRedirects>false</followRedirects>
   <httpBody></httpBody>
   <httpBodyContent></httpBodyContent>
   <httpBodyType></httpBodyType>
   <katalonVersion>9.3.1</katalonVersion>
   <maxResponseSize>0</maxResponseSize>
   <migratedVersion>5.4.1</migratedVersion>
   <restRequestMethod>POST</restRequestMethod>
   <restUrl>https://test.salesforce.com/services/oauth2/token?username=claudia.aranda@iaware.pro.justuat&amp;password=cl4uw4reUAT2021eqgZz9FAi8chpMMvFXniCnvb&amp;client_id=3MVG9AJuBE3rTYDj_z3EBjwkQQWKjs5pfmCUyEcKwv7kXVjGAWyowUYZYP7sBX3DSXLfdBeDJFYSHa0eB8qfO&amp;client_secret=8D86D75F2BBAA8E9C237D9AA8E45FE86EE4DE40F8681E3910D0B9CA9642021DC&amp;grant_type=password</restUrl>
   <serviceType>RESTful</serviceType>
   <soapBody></soapBody>
   <soapHeader></soapHeader>
   <soapRequestMethod></soapRequestMethod>
   <soapServiceEndpoint></soapServiceEndpoint>
   <soapServiceFunction></soapServiceFunction>
   <socketTimeout>0</socketTimeout>
   <useServiceInfoFromWsdl>true</useServiceInfoFromWsdl>
   <variables>
      <defaultValue>''</defaultValue>
      <description></description>
      <id>aca31be2-8cc0-48b2-aa98-3ecd195b919c</id>
      <masked>false</masked>
      <name>TOKENJUST</name>
   </variables>
   <verificationScript>import static org.assertj.core.api.Assertions.*

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webservice.verification.WSResponseManager

import groovy.json.JsonSlurper
import internal.GlobalVariable as GlobalVariable

RequestObject request = WSResponseManager.getInstance().getCurrentRequest()

ResponseObject response = WSResponseManager.getInstance().getCurrentResponse()</verificationScript>
   <wsdlAddress></wsdlAddress>
</WebServiceRequestEntity>
