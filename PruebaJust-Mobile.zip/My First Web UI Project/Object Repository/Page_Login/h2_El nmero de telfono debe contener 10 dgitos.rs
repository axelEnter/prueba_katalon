<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_El nmero de telfono debe contener 10 dgitos</name>
   <tag></tag>
   <elementGuidId>49e3307c-afc7-4a44-8b3c-b0b2211d2376</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'El número de teléfono debe contener 10 dígitos' or . = 'El número de teléfono debe contener 10 dígitos')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='centerPanel']/div/div[2]/div/div/div[3]/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;El número de teléfono debe contener 10 dígitos&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>8fd87084-e383-46cf-a94c-aec81990fc46</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aura-rendered-by</name>
      <type>Main</type>
      <value>63:2;a</value>
      <webElementGuid>fdab0312-b146-45b0-a28c-4376b1df194b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>El número de teléfono debe contener 10 dígitos</value>
      <webElementGuid>ef44bc00-3073-4f52-b455-450c429574d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;centerPanel&quot;)/div[@class=&quot;siteforceSldsOneColLayout siteforceContentArea&quot;]/div[@class=&quot;slds-col--padded contentRegion comm-layout-column&quot;]/div[1]/div[@class=&quot;ui-widget&quot;]/div[@class=&quot;slds-notify slds-notify_alert slds-alert_error cJustLogin&quot;]/h2[1]</value>
      <webElementGuid>c0f40f8c-18cb-4b38-9801-8e00164a009a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='centerPanel']/div/div[2]/div/div/div[3]/h2</value>
      <webElementGuid>177840eb-a031-405d-bd5a-e790fb4626a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='error'])[1]/following::h2[1]</value>
      <webElementGuid>aeff816b-f3fa-4b20-b7de-a2d93b908a32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Down'])[1]/following::h2[1]</value>
      <webElementGuid>41005567-1d62-4325-925e-765c94fb6d42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close'])[1]/preceding::h2[1]</value>
      <webElementGuid>68c7fd2a-5e0f-4d82-b823-e95e2ec89afa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ya no necesitas tu JUST ID para entrar al portal JUST. Usa tu número de teléfono.'])[1]/preceding::h2[2]</value>
      <webElementGuid>1c2d135e-0446-4f3b-bea2-e2e1aa36bd8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='El número de teléfono debe contener 10 dígitos']/parent::*</value>
      <webElementGuid>7a79e8a7-5207-468e-bfa6-82e90940a0ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>70c65198-ad8a-4ded-99fa-d52475848c5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'El número de teléfono debe contener 10 dígitos' or . = 'El número de teléfono debe contener 10 dígitos')]</value>
      <webElementGuid>27258d41-7cf4-4070-96b3-b2d802d1bda3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
